#%%
from setuptools import setup 

with open('requirements.txt') as fid:
    requires = [line.strip() for line in fid]

setup(
    name = 'sabr' , 
    version = '0.0.1',
    author = 'geo' ,
    install_requires=requires
)