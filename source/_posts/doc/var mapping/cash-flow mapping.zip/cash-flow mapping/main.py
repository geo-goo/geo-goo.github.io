#%%
from module import * 

#%%

principal = 1000000
coupon = 5/100 # semi-annually

term = [0.3,0.8]
standard_term = [0.25,0.5,1,1.25]

index_term = ['0.25','0.5','1'] 

df = pd.DataFrame({
    'rate' : np.array([5.5,6,7])/100 ,
    'vol' : np.array([0.06,0.1,0.2])/100},
    index = index_term
    )

# cor = np.mat([[1,0.9,0.6],[0.9,1,0.7],[0.6,0.7,1]])
cor = pd.DataFrame({
    '0.25' : [1,0.9,0.6] , 
    '0.5' : [0.9,1,0.7] ,
    '1' : [0.6,0.7,1] } ,
    index = index_term
    )

# var 
T = 10
confidence_level = 0.99

#%%
cashflow1 = coupon*principal
cashflow2 = principal + coupon*principal

last_term = len(term)-1

induced_risk = []
vars_result = []
allocation_first = []
allocation_second = []
#%% risk metrics

for num,t in enumerate(term):
    if num == last_term :
        t1 , t2 = take_standard_term([t],standard_term)
        corr = cor['{}'.format(t1)]['{}'.format(t2)]
        r2 = interpolation().linear_interpolation(t,[t1,t2,df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt2 = get_present_value(cashflow2,r2,t)
        vol2 = interpolation().linear_interpolation(t,[t1,t2,df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        alpha2 = risk_metrics().get_weight(vol2,[df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)],corr],[0.1,0.2,1e-10,500])
    else :
        t1 , t2 = take_standard_term([t],standard_term)
        corr = cor['{}'.format(t1)]['{}'.format(t2)]
        r1 = interpolation().linear_interpolation(t,[t1,t2,df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt1 = get_present_value(cashflow1,r1,t)
        vol1 = interpolation().linear_interpolation(t,[t1,t2,df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        alpha1 = risk_metrics().get_weight(vol1,[df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)],corr],[0.1,0.2,1e-10,500])
sigma = portfolio().volatility([alpha1*pt1 , (1-alpha1)*pt1 + alpha2*pt2 , (1-alpha2)*pt2],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)

vars_result.append(var().model(sigma,confidence_level,T))
induced_risk.append([alpha1*pt1 , (1-alpha1)*pt1 + alpha2*pt2 , (1-alpha2)*pt2])
allocation_first.append([alpha1,(1-alpha1)])
allocation_second.append([alpha2,(1-alpha2)])

print(var().model(sigma,confidence_level,T))
print(alpha1*pt1 , (1-alpha1)*pt1 + alpha2*pt2 , (1-alpha2)*pt2)

#%% elementary

for num,t in enumerate(term):
    if num == last_term :
        t1 , t2 = take_standard_term([t],standard_term)
        alpha2 = elementary().get_weight(t,[t1,t2])
        rt = elementary().get_rate(t,[t1,t2],[df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt2 = get_present_value(cashflow2,rt,t)

    else :
        t1 , t2 = take_standard_term([t],standard_term)
        alpha1 = elementary().get_weight(t,[t1,t2])
        rt = elementary().get_rate(t,[t1,t2],[df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt1 = get_present_value(cashflow1,rt,t)
        
sigma = portfolio().volatility([alpha1*pt1 , (1-alpha1)*pt1 + alpha2*pt2 , (1-alpha2)*pt2],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)

vars_result.append(var().model(sigma,confidence_level,T))
induced_risk.append([alpha1*pt1 , (1-alpha1)*pt1 + alpha2*pt2 , (1-alpha2)*pt2])
allocation_first.append([alpha1,(1-alpha1)])
allocation_second.append([alpha2,(1-alpha2)])

print(var().model(sigma,confidence_level,T))
print(alpha1*pt1 , (1-alpha1)*pt1 + alpha2*pt2 , (1-alpha2)*pt2)

#%% rates 

for num,t in enumerate(term):
    if num == last_term :
        t1 , t2 = take_standard_term([t],standard_term)
        alpha21 , alpha22 = rates().get_weight(t,[t1,t2])
        rt = rates().get_rate(t,[t1,t2],[df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt2 = get_present_value(cashflow2,rt,t)

    else :
        t1 , t2 = take_standard_term([t],standard_term)
        alpha11 , alpha12 = rates().get_weight(t,[t1,t2])
        rt = rates().get_rate(t,[t1,t2],[df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt1 = get_present_value(cashflow1,rt,t)
        
sigma = portfolio().volatility([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)

vars_result.append(var().model(sigma,confidence_level,T))
induced_risk.append([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22])
allocation_first.append([alpha11,alpha12])
allocation_second.append([alpha21,alpha22])

print(var().model(sigma,confidence_level,T))
print(pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22)
# print(pt1,alpha11)
# print(pt1*alpha11)
#%% schaller 

for num,t in enumerate(term):
    if num == last_term :
        t1 , t2 = take_standard_term([t],standard_term)
        corr = cor['{}'.format(t1)]['{}'.format(t2)]
        vol2 = interpolation().linear_interpolation(t,[t1,t2,df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        rt = interpolation().linear_interpolation(t,[t1,t2,df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt2 = get_present_value(cashflow2,rt,t)
        alpha21 , alpha22 = schaller().get_weight(vol2,t,corr,[t1,t2],[df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])

    else :
        t1 , t2 = take_standard_term([t],standard_term)
        corr = cor['{}'.format(t1)]['{}'.format(t2)]
        vol1 = interpolation().linear_interpolation(t,[t1,t2,df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        rt = interpolation().linear_interpolation(t,[t1,t2,df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt1 = get_present_value(cashflow1,rt,t)
        alpha11 , alpha12 = schaller().get_weight(vol1,t,corr,[t1,t2],[df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        
sigma = portfolio().volatility([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)

vars_result.append(var().model(sigma,confidence_level,T))
induced_risk.append([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22])
allocation_first.append([alpha11,alpha12])
allocation_second.append([alpha21,alpha22])

print(var().model(sigma,confidence_level,T))
print(pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22)


#%% polar coordinates 

for num,t in enumerate(term):
    if num == last_term :
        t1 , t2 = take_standard_term([t],standard_term)
        corr = cor['{}'.format(t1)]['{}'.format(t2)]
        vol2 = interpolation().linear_interpolation(t,[t1,t2,df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        rt = interpolation().linear_interpolation(t,[t1,t2,df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt2 = get_present_value(cashflow2,rt,t)
        alpha21 , alpha22 = polar_coordinates().get_weight(vol2,t,corr,[t1,t2],[df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])

    else :
        t1 , t2 = take_standard_term([t],standard_term)
        corr = cor['{}'.format(t1)]['{}'.format(t2)]
        vol1 = interpolation().linear_interpolation(t,[t1,t2,df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        rt = interpolation().linear_interpolation(t,[t1,t2,df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt1 = get_present_value(cashflow1,rt,t)
        alpha11 , alpha12 = polar_coordinates().get_weight(vol1,t,corr,[t1,t2],[df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        
        # print(rt,alpha11,alpha12)

sigma = portfolio().volatility([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)

vars_result.append(var().model(sigma,confidence_level,T))
induced_risk.append([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22])
allocation_first.append([alpha11,alpha12])
allocation_second.append([alpha21,alpha22])

print(var().model(sigma,confidence_level,T))
print(pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22)
#%% 3 dim 

for num , t in enumerate(term):
    if num == last_term : 
        t1 , t2 , t3 = take_standard_term([t],standard_term,True)
        vol2 = interpolation().linear_interpolation(t,[t1,t2,df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        corr = cor['{}'.format(t1)]['{}'.format(t2)]
        rt = interpolation().linear_interpolation(t,[t1,t2,df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt2 = get_present_value(cashflow2,rt,t)
        alpha21 , alpha22 = three_dimensional().get_weight(vol2,t,t3,corr,[t1,t2],[df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])

    else :
        t1 , t2 , t3 = take_standard_term([t],standard_term,True)
        vol1 = interpolation().linear_interpolation(t,[t1,t2,df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])
        corr = cor['{}'.format(t1)]['{}'.format(t2)]
        rt = interpolation().linear_interpolation(t,[t1,t2,df['rate']['{}'.format(t1)],df['rate']['{}'.format(t2)]])
        pt1 = get_present_value(cashflow1,rt,t)
        alpha11 , alpha12 = three_dimensional().get_weight(vol1,t,t3,corr,[t1,t2],[df['vol']['{}'.format(t1)],df['vol']['{}'.format(t2)]])

sigma = portfolio().volatility([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)


vars_result.append(var().model(sigma,confidence_level,T))
induced_risk.append([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22])
allocation_first.append([alpha11,alpha12])
allocation_second.append([alpha21,alpha22])
# print(alpha21 , alpha22)
# print(alpha11 , alpha12)
# print(pt1,pt2)
# print(cashflow2,cashflow1)
print(var().model(sigma,confidence_level,T))
# print(pt1*alpha11 ,pt1*alpha12 , pt2*alpha21 , pt2*alpha22)
print(pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22)
#%%
data = pd.DataFrame(np.array(induced_risk),index=['risk_metrics','elementary','rates','schaller','polar_coordinates','3 dimensional'])
data.columns = index_term
# data = data.T

vars_result = pd.DataFrame(np.array(vars_result),index=['risk metrics','elementary','rates','schaller','polar_coordinates','3 dimensional'])
vars_result.columns = ['value at risk']

allocation_first = pd.DataFrame(np.array(allocation_first),index=['risk_metrics','elementary','rates','schaller','polar_coordinates','3 dimensional'])
allocation_first.columns = index_term[:2]

allocation_second = pd.DataFrame(np.array(allocation_second),index=['risk_metrics','elementary','rates','schaller','polar_coordinates','3 dimensional'])
allocation_second.columns = index_term[1:3]

differences = data.copy()
#%%
benchmark = np.array(data.T.elementary)
#%%
allocation_first.sum(axis=1)
#%%
allocation_second.sum(axis=1)
#%%
# data.drop('elementary',axis=0)
for i in range(data.shape[0]):
    differences.iloc[i,:] = round(data.iloc[i,:] - benchmark,6)
#%%
differences.to_csv('output/differences.csv',index=False)
data.to_csv('output/allocation result.csv',index=False)
allocation_first.to_csv('output/weight_first.csv',index=False)
allocation_second.to_csv('output/weight_second.csv',index=False)
vars_result.to_csv('output/vars.csv',index=False)

print('-'*100)
print('cash-flow mapping run successful')
print('-'*100)
# %%
