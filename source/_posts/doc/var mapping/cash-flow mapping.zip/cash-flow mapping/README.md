
# 项目用途

现金流映射分配方法

# 项目结构

```
cash flow/
|-- module/
|   |-- __init__.py
|   |-- basic.py
|   |-- cash_flow.py
|   |-- quant.py
|   |-- numeric_analysis.py
|
|-- main.py
|-- README.md
|-- requirements.txt
|-- setup.py
|
|-- output/
|   |-- allocation results.csv
|   |-- differences.csv
|   |-- vars.csv
|   |-- weight_first.csv
|   |-- weight_second.csv
```
# 项目操作

在 `main.py` 决定这些初始值

```
principal = 1000000
coupon = 5/100 # semi-annually

term = [0.3,0.8]
standard_term = [0.25,0.5,1]

df = pd.DataFrame({
    'rate' : np.array([5.5,6,7])/100 ,
    'vol' : np.array([0.06,0.1,0.2])/100},
    index = ['0.25','0.5','1'] 
    )

# cor = np.mat([[1,0.9,0.6],[0.9,1,0.7],[0.6,0.7,1]])
cor = pd.DataFrame({
    '0.25' : [1,0.9,0.6] , 
    '0.5' : [0.9,1,0.7] ,
    '1' : [0.6,0.7,1] } ,
    index = ['0.25','0.5','1']
    )

# var 
T = 10
confidence_level = 0.99

```

保存后离开 , 后设定执行环境


# 虚拟环境设定 

下列指令皆于 `cmd` 或者 `git bash` 等执行

建构一个虚拟环境安装相对应的环境


```
pip install virtualenv # 如果没有安装过的话

conda create -n <name>  # <name> 为自定义部分

source activate <name> # 启动python 虚拟测试环境  
```

在相对应目录底下执行安装套件指令

```
python setup.py install
```

后执行

```
python main.py
```
