#%%
import numpy as np

def take_standard_term(term,standard_term,want_next=False):
    if want_next :
        take_it = []
        if len(term) != 1 :
            for t in term:
                for i in range(len(standard_term)) :
                    if t in standard_term :
                        raise RuntimeError('{} term in standard term ...'.format(t))
                    elif t > standard_term[i] and t < standard_term[i+1] :
                        take_it.append([standard_term[i],standard_term[i+1],standard_term[i+2]])
                        break     
            return np.array(take_it)
        else : 
            for t in term:
                for i in range(len(standard_term)) :
                    if t in standard_term :
                        raise RuntimeError('{} term in standard term ...'.format(t))
                    elif t > standard_term[i] and t < standard_term[i+1] :
                        return standard_term[i],standard_term[i+1],standard_term[i+2]
    else :    
        take_it = []
        if len(term) != 1 :
            for t in term:
                for i in range(len(standard_term)) :
                    if t in standard_term :
                        raise RuntimeError('{} term in standard term ...'.format(t))
                    elif t > standard_term[i] and t < standard_term[i+1] :
                        take_it.append([standard_term[i],standard_term[i+1]])
                        break     
            return np.array(take_it)
        else : 
            for t in term:
                for i in range(len(standard_term)) :
                    if t in standard_term :
                        raise RuntimeError('{} term in standard term ...'.format(t))
                    elif t > standard_term[i] and t < standard_term[i+1] :
                        return standard_term[i],standard_term[i+1]
        

def get_present_value(cashflow,r,t,iscon=False):
    '''
    cashflow : float
    r : rate such as zero rate
    t : time (year)
    iscon : 
        True : continuously compounding
        False : annual compounding
    '''
    if iscon : 
        return cashflow*np.exp(-r*t)
    else : 
        return cashflow/(1+r)**t

#%%
