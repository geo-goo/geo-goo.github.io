import numpy as np

class numeric_analysis:
    '''
    newton method
    '''
    def newton(self, xo ,tol , no , f , fx ):
        '''
        xo : initial approximation  
        TOL : tolerance  
        no : maximum number of iterations
        f : function
        fx : derative function
        '''
        i = 0
        while i <= no :
            try:
                f1 = f(xo)
                f2 = fx(xo)
                x = xo - (  f1 / f2 ) 
            except ZeroDivisionError:
                continue
            if np.abs(x-xo) < tol :
                return x
            i+=1
            xo = x
        return float('nan')

    '''
    secant method
    '''
    def secant(self,po , p1 , tol , no , f ):
        '''
        po , p1 : initial approximations
        TOL : tolerance
        no : maximum number of iterations
        '''
        i = 2 
        qo = f(po)
        q1 = f(p1)
        while i <= no : 
            p = p1 - q1*(p1-po) / (q1 - qo)
            if np.abs(p - p1) < tol :
                return p
            i+=1
            po , qo , p1 , q1 = p1 , q1 , p , f(p)
        return float('nan')   

    '''
    bisection method
    '''
    def bisection(self, start , end , tol , no , f):
        '''
        start : start points 
        end : end points 
        tol : tolerance 
        no : maximum number of iterations 
        '''
        i = 1 
        st = start
        et = end
        fa = f(st)
        while i <= no:
            p = st + (et-st)/2
            fp = f(p)
            if fp == 0 or (et-st)/2 < tol :
                return p
            i+=1
            if fa * fp > 0 :
                st , fa  = p , fp
            elif fa * fp < 0 : 
                et = p
        return float('nan')
