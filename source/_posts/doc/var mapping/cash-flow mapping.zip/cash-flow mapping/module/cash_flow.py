#%%

import numpy as np
import pandas as pd
import scipy.stats as stats
from module.numeric_analysis import *
#%%

class risk_metrics:
    '''
    risk metrics cash flow mapping
    '''
    def get_weight(self,sigma,params,opt,issecant=True):
        '''
        also call get_weight
        sigma : sigma of target
        sigma1,sigma2,rho = params
        start,end,tol,no = opt
        start,end :
            start : start points for bisection 
            end : end points for bisection 
            p0 , p1 : initial approximations for secant
        TOL : tolerance
        no : maximum number of iterations
        issecant : 
            True : secant
            False : bisection

        example : 

        risk_metrics().find_root(0.0016,[0.001,0.002,0.7],[0.1,0.5,1e-14,500])
        >> 0.3203376188740266
        '''
        sigma1,sigma2,rho = params
        start,end,tol,no = opt
        a = sigma1**2 - 2*rho*sigma1*sigma2 + sigma2**2
        b = 2*rho*sigma1*sigma2 - 2*sigma2*sigma2
        c = sigma2**2 - sigma**2
        f = lambda x : a * x**2 + b * x + c  
        if issecant :
            r = numeric_analysis().secant(start,end,tol,no,f)
        else :
            p0 , p1 = start , end
            r = numeric_analysis().bisection(p0,p1,tol,no,f)
        return r

    def proof_root(self,sigma,params,error=1e-10,isproof=False):
        '''
        sigma1,sigma2,rho,alpha1 = params
        '''
        sigma1,sigma2,rho,alpha1 = params
        alpha2 = 1-alpha1
        func = (alpha1*alpha1*sigma1*sigma1+alpha2*alpha2*sigma2*sigma2+2*rho*sigma2*sigma1*alpha2*alpha1) - sigma**2 
        if isproof :
            return np.where(func<error,True,False)
        else :
            return func
    
class portfolio:
    '''
    financial portfolio
    '''
    def volatility(self,weight,sigma,cor):
        '''
        weight : np.array([])
        sigma : ...
        cor : ... 
        '''
        w = np.mat(np.array(weight)*np.array(sigma))
        return np.sqrt(np.dot(np.dot(w,cor),w.T))[0,0]

class var:
    '''
    var
    '''
    def model(self,sigma,confidence_level,t):
        '''
        sigma : portfolio sigma
        confidence_level : float 
        t : target t 

        example : 
            var().model(sigma,0.99,10)
        '''
        alpha = 1 - confidence_level
        return sigma*stats.norm.ppf(alpha)*np.sqrt(t)

class elementary:
    '''
    elementary cash flow mapping
    '''
    def get_weight(self,t,params):
        t1, t2 = params
        alpha = (t2 - t)/(t2-t1)
        return  alpha 

    def get_rate(self,t,params,r_params):
        '''
        t1 , t2 = params 
        r1 , r2 = r_params
        '''
        t1 , t2 = params
        r1 , r2 = r_params
        x = self.get_weight(t,params)
        return x*t1*r1/t+(1-x)*t2*r2/t

class rates:
    '''
    rates cash flow mapping
    '''
    def get_rate(self,t,params,r_params):
        '''
        t1 , t2 = params 
        r1 , r2 = r_params
        '''
        t1, t2 = params
        r1 , r2 = r_params
        x = (t2 - t)/(t2-t1)
        # x = self.get_weight(t,params)
        return x*r1+(1-x)*r2

    def get_weight(self,t,params):
        '''
        t1 , t2 = params 
        '''
        t1 , t2 = params 
        a1 = t/t1 *  (t2-t)/(t2-t1)
        a2 = t/t2 * (t-t1)/(t2-t1)
        return a1 , a2

class schaller:
    '''
    schaller cahs flow mapping
    '''
    def __get_tau(self,t,parmas):
        t1 , t2 = parmas
        return (t-t1)/(t2-t)

    def get_weight(self,sigma,t,rho,params,sparams):
        '''
        sigma : target sigma
        t : target term
        rho : correlation
        t1 , t2 = params
        sigma1 , sigma2 = sparams

        example:
            schaller().get_weight(0.1,0.8,0.7,[0.1,0.2],[0.016,0.012])
            >> (8.500255011475575, 9.916964180054837)
        '''
        tau = self.__get_tau(t,params)
        sigma1 ,sigma2 = sparams 
        a1 = sigma/np.sqrt(sigma1*sigma1+sigma2*sigma2*tau*tau+2*sigma1*sigma2*rho*tau)
        a2 = sigma/np.sqrt(sigma1**2/tau**2+sigma2**2+2*sigma1*sigma2*rho/tau)
        return a1 , a2

class polar_coordinates:
    '''
    polar coordinates cahs flow mapping
    '''
    def __get_beta(self,rho,t,params):
        t1 , t2 = params
        x = np.arccos(rho)
        return x , (t-t1)/(t2-t1)*x

    def get_weight(self,sigma,t,rho,params,sparams):
        '''
        sigma : target sigma 
        rho : correlation
        t : target term
        t1 , t2 = params
        sigma1 , sigma2 = sparams
        '''
        sigma1 , sigma2 = sparams
        x , beta = self.__get_beta(rho,t,params)
        a1 = np.sin(x-beta)/np.sqrt(1-rho*rho)*sigma/sigma1
        a2 = np.sin(beta)/np.sqrt(1-rho*rho)*sigma/sigma2
        return a1 , a2

class three_dimensional:
    '''
    three dimensional cash flow mapping
    '''
    def __get_rho(self,rho,t,t3,params):
        t1 , t2 = params
        rho1 , rho2 = 1+(t-t1)/(t2-t1)*(rho-1) , 1+(t-t2)/(t1-t2)*(rho-1)
        return rho1 , rho2

    def get_weight(self,sigma,t,t3,rho,params,sparams):
        '''
        sigma : target sigma 
        rho : correlation
        t : target term
        t1 , t2 = params
        sigma1 , sigma2 = sparams
        '''
        rho1 , rho2 = self.__get_rho(rho,t,t3,params)
        # print('{} , {}'.format(rho1,rho2))
        sigma1 , sigma2 = sparams
        a1 = sigma / sigma1 * (rho1-rho2*rho)/(1-rho*rho)
        a2 = sigma / sigma2 * (rho2-rho1*rho)/(1-rho*rho) 
        return a1 , a2 
#%%

#%%
# x = False
# if x :
#     ...
# else :
#     raise RuntimeError('you are wrong')
#%%