
import numpy as np

class interpolation:

    def linear_interpolation(self,xi,params):
        '''
        linear interpolation method

        x1 ：  Lower point on the X-axis
        x2 ：  Higher point on the X-axis
        xi ：  Point on the X-axis to be interpolated (target)
        y1 ：  Lower point on the Y-axis
        y2 ：  Higher point on the Y-axis
        '''
        x1,x2,y1,y2 = params
        return y2 * (xi-x1) /(x2-x1) + y1 * (x2-xi) / (x2-x1)

    def log_linear_interpolation(self,xi,params):
        x1,x2,y1,y2 = params
        return np.exp((np.log(y2) * (xi-x1) /(x2-x1) + np.log(y1) * (x2-xi) / (x2-x1)))
