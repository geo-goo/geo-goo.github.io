#%%
from module import * 

#%%

principal = 1000000
coupon = 5/100 # semi-annually

df = pd.DataFrame({
    'rate' : np.array([5.5,6,7])/100 ,
    'vol' : np.array([0.06,0.1,0.2])/100
})

cor = np.mat([[1,0.9,0.6],[0.9,1,0.7],[0.6,0.7,1]])

#%% bond price info

cashflow1 = coupon*principal
cashflow2 = principal + coupon*principal

#%% risk metrics

t = 0.3

r1 = interpolation().linear_interpolation(t,[0.25,0.5,df['rate'][0],df['rate'][1]])
pt1 = get_present_value(cashflow1,r1,t)
vol1 = interpolation().linear_interpolation(t,[0.25,0.5,df['vol'][0],df['vol'][1]])
alpha1 = risk_metrics().get_weight(vol1,[df['vol'][0],df['vol'][1],cor[0,1]],[0.1,0.2,1e-10,500])
pt1*alpha1 , pt1*(1-alpha1)

t = 0.8

r2 = interpolation().linear_interpolation(t,[0.5,1,df['rate'][1],df['rate'][2]])
pt2 = get_present_value(cashflow2,r2,t)
vol2 = interpolation().linear_interpolation(t,[0.5,1,df['vol'][1],df['vol'][2]])
alpha2 = risk_metrics().get_weight(vol2,[df['vol'][1],df['vol'][2],cor[1,2]],[0.1,0.2,1e-10,500])
pt2*alpha2 , pt2*(1-alpha2)

sigma = portfolio().volatility([alpha1*pt1 , (1-alpha1)*pt1 + alpha2*pt2 , (1-alpha2)*pt2],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)
var().model(sigma,0.99,10)


#%% elementary 
t = 0.3

alpha1 = elementary().get_weight(t,[0.25,0.5])
rt = elementary().get_rate(t,[0.25,0.5],[df['rate'][0],df['rate'][1]])
pt1 = get_present_value(cashflow1,rt,t)
pt1*alpha1 , pt1*(1-alpha1)

t = 0.8

alpha2 = elementary().get_weight(t,[0.5,1])
rt = elementary().get_rate(t,[0.5,1],[df['rate'][1],df['rate'][2]])
pt2 = get_present_value(cashflow2,rt,t)
pt2*alpha2 , pt2*(1-alpha2)

sigma = portfolio().volatility([alpha1*pt1 , (1-alpha1)*pt1 + alpha2*pt2 , (1-alpha2)*pt2],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)
var().model(sigma,0.99,10)

#%% rates 

t = 0.3
alpha11 , alpha12 = rates().get_weight(t,[0.25,0.5])
rt = rates().get_rate(t,[0.25,0.5],[df['rate'][0],df['rate'][1]])
pt1 = get_present_value(cashflow1,rt,t)
pt1*alpha11 , pt1*alpha12

t = 0.8
alpha21 , alpha22 = rates().get_weight(t,[0.5,1])
rt = rates().get_rate(t,[0.5,1],[df['rate'][1],df['rate'][2]])
pt2 = get_present_value(cashflow2,rt,t)
pt2*alpha21 , pt2*alpha22

sigma = portfolio().volatility([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)
var().model(sigma,0.99,10)

# print(alpha11,alpha12)
# print(alpha21,alpha22)
#%% schaller 

t = 0.3
vol1 = interpolation().linear_interpolation(t,[0.25,0.5,df['vol'][0],df['vol'][1]])
rt = interpolation().linear_interpolation(t,[0.25,0.5,df['rate'][0],df['rate'][1]])
pt1 = get_present_value(cashflow1,rt,t)
alpha11 , alpha12 = schaller().get_weight(vol1,t,cor[0,1],[0.25,0.5],[df['vol'][0],df['vol'][1]])
pt1*alpha11 , pt1*alpha12

t = 0.8
vol2 = interpolation().linear_interpolation(t,[0.5,1,df['vol'][1],df['vol'][2]])
rt = interpolation().linear_interpolation(t,[0.5,1,df['rate'][1],df['rate'][2]])
pt2 = get_present_value(cashflow2,rt,t)
alpha21 , alpha22 = schaller().get_weight(vol2,t,cor[1,2],[0.5,1],[df['vol'][1],df['vol'][2]])
pt2*alpha21 , pt2*alpha22

sigma = portfolio().volatility([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)
var().model(sigma,0.99,10)

# print(alpha11,alpha12)
# print(alpha21,alpha22)

#%% polar coordinates 

t = 0.3
vol1 = interpolation().linear_interpolation(t,[0.25,0.5,df['vol'][0],df['vol'][1]])
rt = interpolation().linear_interpolation(t,[0.25,0.5,df['rate'][0],df['rate'][1]])
pt1 = get_present_value(cashflow1,rt,t)
alpha11 , alpha12 = polar_coordinates().get_weight(vol1,t,cor[0,1],[0.25,.5],[df['vol'][0],df['vol'][1]])
pt1*alpha11 , pt1*alpha12

t = 0.8
vol2 = interpolation().linear_interpolation(t,[0.5,1,df['vol'][1],df['vol'][2]])
rt = interpolation().linear_interpolation(t,[0.5,1,df['rate'][1],df['rate'][2]])
pt2 = get_present_value(cashflow2,rt,t)
alpha21 , alpha22 = polar_coordinates().get_weight(vol2,t,cor[1,2],[0.5,1],[df['vol'][1],df['vol'][2]])
pt2*alpha21 , pt2*alpha22

# print(alpha11,alpha12)
# print(alpha21,alpha22)

sigma = portfolio().volatility([pt1*alpha11 ,pt1*alpha12 + pt2*alpha21 , pt2*alpha22],[df['vol'][0],df['vol'][1],df['vol'][2]],cor)
var().model(sigma,0.99,10)

#%% 3 dim 暂时先不写

#%% VaR Result

# -11926.96000511585
# -11235.325603753283
# -11066.288245890064
# -11931.967582825562
# -11944.4787215154

# 后面优化问题
# 后续可以把折现值的计算更灵活